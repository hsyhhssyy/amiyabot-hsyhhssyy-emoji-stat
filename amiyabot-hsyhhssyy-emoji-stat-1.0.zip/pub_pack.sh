#!/bin/sh

rm amiyabot-hsyhhssyy-emoji-stat-*.zip
zip -q -r amiyabot-hsyhhssyy-emoji-stat-1.0.zip *